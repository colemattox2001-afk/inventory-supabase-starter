export default { images: { remotePatterns: [] } };
